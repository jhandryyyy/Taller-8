import java.util.ArrayList;
import java.util.List;

public class Lista {
    private ArrayList<Paqueteria> serviEntrega;

    public Lista() {
        serviEntrega = new ArrayList<>();
    }

    public ArrayList<Paqueteria> getServiEntrega() {
        return serviEntrega;
    }

    public void adicionarElementos(Paqueteria p) throws Exception {
        if (p.getTracking() <= 0) {
            throw new Exception("El Tracking debe ser mayor que cero");
        }
        validarDatos(p.getPeso(), p.getCiudadRecepcion(), p.getCiudadEntrega(), p.getCedulaReceptor());
        for (Paqueteria paquete : serviEntrega) {
            if (paquete.getTracking() == p.getTracking()) {
                throw new Exception("Ya existe un paquete con ese tracking");
            }
        }
        serviEntrega.add(p);
    }

    public String listarPaquetes() {
        if (serviEntrega.isEmpty()) {
            return "No hay paquetes registrados";
        }
        StringBuilder sb = new StringBuilder();
        for (Paqueteria p : serviEntrega) {
            sb.append(p.toString()).append("\n");
        }
        return sb.toString();
    }

    public Paqueteria buscarPaquete(int tracking) throws Exception {
        for (Paqueteria p : serviEntrega) {
            if (p.getTracking() == tracking) {
                return p;
            }
        }
        throw new Exception("No existe un paquete con ese numero de tracking");
    }

    public void editar(int tracking, double peso, String ciudadRecepcion, String ciudadEntrega, String cedulaReceptor) throws Exception {
        validarDatos(peso, ciudadRecepcion, ciudadEntrega, cedulaReceptor);
        Paqueteria p = buscarPaquete(tracking);
        p.setPeso(peso);
        p.setCiudadRecepcion(ciudadRecepcion);
        p.setCiudadEntrega(ciudadEntrega);
        p.setCedulaReceptor(cedulaReceptor);
    }

    private void validarDatos(double peso, String ciudadRecepcion, String ciudadEntrega, String cedula) throws Exception {
        if (peso <= 0) {
            throw new Exception("El peso debe ser mayor que 0.");
        }
        if (ciudadRecepcion == null || ciudadRecepcion.trim().isEmpty()
                || ciudadEntrega == null || ciudadEntrega.trim().isEmpty()) {
            throw new Exception("Debe seleccionar la ciudad de recepción y de entrega.");
        }
        if (cedula == null || !cedula.trim().matches("\\d+")) {
            throw new Exception("La cédula del receptor es obligatoria y solo debe contener números.");
        }
    }

    public String estadoPaquete(int tracking) {
        Paqueteria p = null;
        for (Paqueteria paquete : serviEntrega) {
            if (paquete.getTracking() == tracking) {
                p = paquete;
                break;
            }
        }
        if (p == null) {
            throw new IllegalArgumentException("No existe un paquete con el tracking " + tracking);
        }
        switch (p.getEstado()) {
            case "Receptado":
                p.setEstado("Enviado");
                return "Enviado";
            case "Enviado":
                p.setEstado("Recibido");
                return "Recibido";
            default:
                return "Finalizado";
        }
    }

    // ===== RECURSIVIDAD =====

    // Recursividad: total de paquetes
    public int sumarTotalPaquetes() {
        return contarPaquetes(0);
    }

    private int contarPaquetes(int i) {
        if (i == serviEntrega.size()) {
            return 0; // caso base
        }
        return 1 + contarPaquetes(i + 1); // caso recursivo
    }

    // Recursividad: suma de todos los pesos
    public double sumarTotalPeso() {
        return sumarPesos(0);
    }

    private double sumarPesos(int i) {
        if (i == serviEntrega.size()) {
            return 0; // caso base
        }
        return serviEntrega.get(i).getPeso() + sumarPesos(i + 1); // caso recursivo
    }

    // Recursividad: peso total de los paquetes recibidos en una ciudad
    public double sumarTotalPesoCiudad(String ciudad) {
        return sumarPesoCiudad(0, ciudad);
    }

    private double sumarPesoCiudad(int i, String ciudad) {
        if (i == serviEntrega.size()) {
            return 0; // caso base
        }
        Paqueteria p = serviEntrega.get(i);
        double pesoActual = 0;
        if (p.getCiudadRecepcion().equalsIgnoreCase(ciudad)) {
            pesoActual = p.getPeso();
        }
        return pesoActual + sumarPesoCiudad(i + 1, ciudad); // caso recursivo
    }

    // Recursividad: cantidad de paquetes en un estado
    public int sumarTotalPaquetesEstado(String estado) {
        return contarPorEstado(0, estado);
    }

    private int contarPorEstado(int i, String estado) {
        if (i == serviEntrega.size()) {
            return 0; // caso base
        }
        int cuenta = 0;
        if (serviEntrega.get(i).getEstado().equalsIgnoreCase(estado)) {
            cuenta = 1;
        }
        return cuenta + contarPorEstado(i + 1, estado); // caso recursivo
    }

    // ===== ORDENAMIENTO =====

    // Ordenamiento burbuja: por tracking ascendente
    public List<Paqueteria> ordenarPaquetesPorTracking() {
        List<Paqueteria> copia = new ArrayList<>(serviEntrega);
        int n = copia.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - 1 - i; j++) {
                if (copia.get(j).getTracking() > copia.get(j + 1).getTracking()) {
                    Paqueteria aux = copia.get(j);
                    copia.set(j, copia.get(j + 1));
                    copia.set(j + 1, aux);
                }
            }
        }
        return copia;
    }

    // Ordenamiento por inserción: por peso ascendente
    public List<Paqueteria> ordenarPaquetesPorPeso() {
        List<Paqueteria> copia = new ArrayList<>(serviEntrega);
        for (int i = 1; i < copia.size(); i++) {
            Paqueteria actual = copia.get(i);
            int j = i - 1;
            while (j >= 0 && copia.get(j).getPeso() > actual.getPeso()) {
                copia.set(j + 1, copia.get(j));
                j--;
            }
            copia.set(j + 1, actual);
        }
        return copia;
    }

    // ===== BÚSQUEDA =====

    // Búsqueda binaria: por tracking en una lista ordenada
    public int busquedaBinaria(List<Paqueteria> listaOrdenada, int tracking) {
        int inicio = 0;
        int fin = listaOrdenada.size() - 1;
        while (inicio <= fin) {
            int medio = (inicio + fin) / 2;
            if (listaOrdenada.get(medio).getTracking() == tracking) {
                return medio;
            } else if (listaOrdenada.get(medio).getTracking() < tracking) {
                inicio = medio + 1;
            } else {
                fin = medio - 1;
            }
        }
        return -1;
    }

    // Búsqueda por criterios combinados: cédula y estado
    public List<Paqueteria> buscarPaquetesPorCedulaYEstado(String cedula, String estado) {
        List<Paqueteria> resultado = new ArrayList<>();
        for (Paqueteria p : serviEntrega) {
            if (p.getCedulaReceptor().equals(cedula.trim()) && p.getEstado().equalsIgnoreCase(estado)) {
                resultado.add(p);
            }
        }
        return resultado;
    }
}
