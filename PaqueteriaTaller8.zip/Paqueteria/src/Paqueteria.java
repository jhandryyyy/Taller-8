/**
 * Representa un paquete registrado en el sistema de paquetería.
 */
public class Paqueteria {

    // Atributos privados (encapsulamiento)
    private int tracking;
    private double peso;
    private String ciudadRecepcion;
    private String ciudadEntrega;
    private String cedulaReceptor;
    private String estado;

    /**
     * Constructor: inicializa los datos y asigna automáticamente el estado "Receptado".
     */
    public Paqueteria(int tracking, double peso, String ciudadRecepcion,
                      String ciudadEntrega, String cedulaReceptor) {
        this.tracking = tracking;
        this.peso = peso;
        this.ciudadRecepcion = ciudadRecepcion;
        this.ciudadEntrega = ciudadEntrega;
        this.cedulaReceptor = cedulaReceptor;
        this.estado = "Receptado";
    }

    // ===== Getters y Setters =====

    public int getTracking() {
        return tracking;
    }

    public void setTracking(int tracking) {
        this.tracking = tracking;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public String getCiudadRecepcion() {
        return ciudadRecepcion;
    }

    public void setCiudadRecepcion(String ciudadRecepcion) {
        this.ciudadRecepcion = ciudadRecepcion;
    }

    public String getCiudadEntrega() {
        return ciudadEntrega;
    }

    public void setCiudadEntrega(String ciudadEntrega) {
        this.ciudadEntrega = ciudadEntrega;
    }

    public String getCedulaReceptor() {
        return cedulaReceptor;
    }

    public void setCedulaReceptor(String cedulaReceptor) {
        this.cedulaReceptor = cedulaReceptor;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "Tracking: " + tracking +
                " | Peso: " + peso + " kg" +
                " | Recepción: " + ciudadRecepcion +
                " | Entrega: " + ciudadEntrega +
                " | Cédula: " + cedulaReceptor +
                " | Estado: " + estado;
    }
}
