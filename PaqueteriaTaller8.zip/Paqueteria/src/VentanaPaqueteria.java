import javax.swing.*;
import java.util.List;

public class VentanaPaqueteria {
    private JPanel ventana;
    private JTabbedPane tabbedPane1;
    private JSpinner spinner1;
    private JComboBox comboBox1;
    private JComboBox comboBox2;
    private JTextField textField1;
    private JTextField textField2;
    private JButton agregarButton;
    private JButton totalPaquetesButton;
    private JComboBox comboBox3;
    private JButton totalPesoPorCiudadButton;
    private JButton totalPesosButton;
    private JList list1;
    private JButton modificarButton;
    private JTextField textField3;
    private JButton modificarEstadoDelPaqueteButton;
    private JButton ordenarPorBurbujaButton;
    private JButton ordenarPorInserciónButton;
    private JList list2;
    private JList list3;
    private JComboBox comboBox4;
    private JButton calcularButton;
    private JTextField textField4;
    private JButton buscarButton;
    private JList list4;
    private JTextField textField5;
    private JList list5;
    private JComboBox comboBox5;
    private JButton buscarPorCedulaEstadoButton;

    private Lista paquetes = new Lista();

    public VentanaPaqueteria() {
        spinner1.setModel(new SpinnerNumberModel(1, 1, 999999, 1));
        quemarDatos();
        llenarJlist();

        agregarButton.addActionListener(e -> {
            try {
                int tracking = (Integer) spinner1.getValue();
                double peso = leerPeso();
                paquetes.adicionarElementos(new Paqueteria(tracking, peso,
                        comboBox1.getSelectedItem().toString(),
                        comboBox2.getSelectedItem().toString(),
                        textField2.getText().trim()));
                JOptionPane.showMessageDialog(null, "Paquete agregado");
                llenarJlist();
                limpiarDatos();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage());
            }
        });

        list1.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && list1.getSelectedIndex() != -1) {
                Paqueteria pa = (Paqueteria) list1.getSelectedValue();
                spinner1.setValue(pa.getTracking());
                textField1.setText(String.valueOf(pa.getPeso()));
                comboBox1.setSelectedItem(pa.getCiudadRecepcion());
                comboBox2.setSelectedItem(pa.getCiudadEntrega());
                textField2.setText(pa.getCedulaReceptor());
            }
        });

        modificarButton.addActionListener(e -> {
            if (list1.getSelectedIndex() == -1) {
                JOptionPane.showMessageDialog(null, "Seleccione un paquete de la lista");
                return;
            }
            try {
                Paqueteria seleccionado = (Paqueteria) list1.getSelectedValue();
                paquetes.editar(seleccionado.getTracking(), leerPeso(),
                        comboBox1.getSelectedItem().toString(),
                        comboBox2.getSelectedItem().toString(),
                        textField2.getText().trim());
                JOptionPane.showMessageDialog(null, "Paquete modificado");
                llenarJlist();
                limpiarDatos();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage());
            }
        });

        modificarEstadoDelPaqueteButton.addActionListener(e -> {
            try {
                int tracking = Integer.parseInt(textField3.getText().trim());
                String nuevoEstado = paquetes.estadoPaquete(tracking);
                if (nuevoEstado.equals("Finalizado")) {
                    JOptionPane.showMessageDialog(null, "El paquete " + tracking
                            + " ya fue recibido. El proceso de envío ha finalizado.");
                } else {
                    JOptionPane.showMessageDialog(null, "El paquete " + tracking
                            + " cambió al estado: " + nuevoEstado);
                }
                llenarJlist();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Ingrese un número de tracking válido");
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage());
            }
        });

        totalPaquetesButton.addActionListener(e ->
                JOptionPane.showMessageDialog(null, "El total de paquetes es: " + paquetes.sumarTotalPaquetes()));

        totalPesosButton.addActionListener(e ->
                JOptionPane.showMessageDialog(null, "El peso total de los paquetes es: " + paquetes.sumarTotalPeso() + " kg"));

        totalPesoPorCiudadButton.addActionListener(e -> {
            String ciudad = comboBox3.getSelectedItem().toString();
            JOptionPane.showMessageDialog(null, "El peso total de los paquetes recibidos en " + ciudad
                    + " es: " + paquetes.sumarTotalPesoCiudad(ciudad) + " kg");
        });

        calcularButton.addActionListener(e -> {
            String estado = comboBox4.getSelectedItem().toString();
            JOptionPane.showMessageDialog(null, "Total de paquetes en estado " + estado + ": "
                    + paquetes.sumarTotalPaquetesEstado(estado));
        });

        ordenarPorBurbujaButton.addActionListener(e -> {
            llenarJlistOriginal();
            llenarJlistOrdenada(paquetes.ordenarPaquetesPorTracking());
        });

        ordenarPorInserciónButton.addActionListener(e -> {
            llenarJlistOriginal();
            llenarJlistOrdenada(paquetes.ordenarPaquetesPorPeso());
        });

        buscarButton.addActionListener(e -> {
            try {
                int tracking = Integer.parseInt(textField4.getText().trim());
                List<Paqueteria> listaOrdenada = paquetes.ordenarPaquetesPorTracking();
                int posicion = paquetes.busquedaBinaria(listaOrdenada, tracking);
                DefaultListModel dlm = new DefaultListModel();
                if (posicion != -1) {
                    dlm.addElement(listaOrdenada.get(posicion));
                    JOptionPane.showMessageDialog(null, "Paquete encontrado en la posición " + posicion);
                } else {
                    JOptionPane.showMessageDialog(null, "Paquete no encontrado (posición -1)");
                }
                list4.setModel(dlm);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Ingrese un número de tracking válido");
            }
        });

        buscarPorCedulaEstadoButton.addActionListener(e -> {
            String cedula = textField5.getText().trim();
            if (cedula.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Ingrese una cédula");
                return;
            }
            String estado = comboBox5.getSelectedItem().toString();
            List<Paqueteria> resultado = paquetes.buscarPaquetesPorCedulaYEstado(cedula, estado);
            DefaultListModel dlm = new DefaultListModel();
            if (resultado.isEmpty()) {
                dlm.addElement("No se encontraron paquetes con esa cédula y estado");
            } else {
                for (Paqueteria p : resultado) {
                    dlm.addElement(p);
                }
            }
            list5.setModel(dlm);
        });
    }

    private double leerPeso() throws Exception {
        try {
            return Double.parseDouble(textField1.getText().trim().replace(',', '.'));
        } catch (NumberFormatException ex) {
            throw new Exception("Ingrese un peso válido");
        }
    }

    public void limpiarDatos() {
        spinner1.setValue(1);
        textField1.setText("");
        comboBox1.setSelectedIndex(0);
        comboBox2.setSelectedIndex(0);
        textField2.setText("");
        list1.clearSelection();
    }

    public void quemarDatos() {
        try {
            paquetes.adicionarElementos(new Paqueteria(5, 25, "Quito", "Guayaquil", "1111111111"));
            paquetes.adicionarElementos(new Paqueteria(2, 15, "Cuenca", "Riobamba", "2222222222"));
            paquetes.adicionarElementos(new Paqueteria(7, 55, "Guayaquil", "Ibarra", "3333333333"));
            paquetes.adicionarElementos(new Paqueteria(3, 8.5, "Quito", "Cuenca", "1111111111"));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }

    public void llenarJlist() {
        DefaultListModel dlm = new DefaultListModel();
        for (Paqueteria p : paquetes.getServiEntrega()) {
            dlm.addElement(p);
        }
        list1.setModel(dlm);
    }

    public void llenarJlistOriginal() {
        DefaultListModel dlm = new DefaultListModel();
        for (Paqueteria p : paquetes.getServiEntrega()) {
            dlm.addElement(p);
        }
        list2.setModel(dlm);
    }

    public void llenarJlistOrdenada(List<Paqueteria> lista) {
        DefaultListModel dlm = new DefaultListModel();
        for (Paqueteria p : lista) {
            dlm.addElement(p);
        }
        list3.setModel(dlm);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Sistema de Paquetería");
        frame.setContentPane(new VentanaPaqueteria().ventana);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
